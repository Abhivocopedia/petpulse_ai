
module.exports = [
  { species: 'Dog', breed: 'Labrador Retriever', lifespan: '10-12 years', commonIssues: ['hip dysplasia','ear infections'] },
  { species: 'Dog', breed: 'German Shepherd', lifespan: '9-13 years', commonIssues: ['elbow dysplasia','degenerative myelopathy'] },
  { species: 'Cat', breed: 'Siamese', lifespan: '15-20 years', commonIssues: ['respiratory issues'] }
];
