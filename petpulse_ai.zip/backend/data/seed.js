
/*
  Run manually: node data/seed.js
  This will insert sample breed data.
*/
const mongoose = require('mongoose');
const connectDB = require('../config/database');
const breedData = require('./breedData');

async function run(){
  await connectDB();
  console.log('Seed sample breed data (printed):');
  console.log(breedData);
  process.exit(0);
}
run();
