
const mongoose = require('mongoose');

const VaccinationSchema = new mongoose.Schema({
  pet: { type: mongoose.Schema.Types.ObjectId, ref: 'Pet', required: true },
  name: { type: String, required: true },
  date: { type: Date, required: true },
  nextDue: { type: Date },
  notes: { type: String }
});

module.exports = mongoose.model('Vaccination', VaccinationSchema);
