
const mongoose = require('mongoose');

const HealthRecordSchema = new mongoose.Schema({
  pet: { type: mongoose.Schema.Types.ObjectId, ref: 'Pet', required: true },
  symptoms: [{ type: String }],
  diagnosis: { type: String },
  treatment: { type: String },
  date: { type: Date, default: Date.now },
  notes: { type: String }
});

module.exports = mongoose.model('HealthRecord', HealthRecordSchema);
