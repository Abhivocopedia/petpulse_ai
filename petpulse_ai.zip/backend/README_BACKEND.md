Backend quick start: fill .env, npm install, npm run start
