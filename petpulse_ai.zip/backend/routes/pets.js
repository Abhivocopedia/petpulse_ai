
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Pet = require('../models/Pet');

// Create pet
router.post('/', auth, async (req, res) => {
  try{
    const pet = new Pet({ owner: req.user.id, ...req.body });
    await pet.save();
    res.json(pet);
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

// Get all pets for user
router.get('/', auth, async (req, res) => {
  try{
    const pets = await Pet.find({ owner: req.user.id });
    res.json(pets);
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

// Get one
router.get('/:id', auth, async (req, res) => {
  try{
    const pet = await Pet.findById(req.params.id);
    if(!pet) return res.status(404).json({ msg:'Pet not found' });
    if(pet.owner.toString() !== req.user.id) return res.status(401).json({ msg:'Not authorized' });
    res.json(pet);
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

// Update
router.put('/:id', auth, async (req, res) => {
  try{
    let pet = await Pet.findById(req.params.id);
    if(!pet) return res.status(404).json({ msg:'Pet not found' });
    if(pet.owner.toString() !== req.user.id) return res.status(401).json({ msg:'Not authorized' });
    pet = await Pet.findByIdAndUpdate(req.params.id, { $set: req.body }, { new: true });
    res.json(pet);
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

// Delete
router.delete('/:id', auth, async (req, res) => {
  try{
    const pet = await Pet.findById(req.params.id);
    if(!pet) return res.status(404).json({ msg:'Pet not found' });
    if(pet.owner.toString() !== req.user.id) return res.status(401).json({ msg:'Not authorized' });
    await pet.remove();
    res.json({ msg:'Pet removed' });
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

module.exports = router;
