
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Vaccination = require('../models/Vaccination');
const Pet = require('../models/Pet');

// Add vaccination
router.post('/', auth, async (req, res) => {
  try{
    const pet = await Pet.findById(req.body.pet);
    if(!pet) return res.status(404).json({ msg:'Pet not found' });
    if(pet.owner.toString() !== req.user.id) return res.status(401).json({ msg:'Not authorized' });
    const vac = new Vaccination(req.body);
    await vac.save();
    res.json(vac);
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

// Get vaccinations for a pet
router.get('/pet/:petId', auth, async (req, res) => {
  try{
    const vacs = await Vaccination.find({ pet: req.params.petId });
    res.json(vacs);
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

module.exports = router;
