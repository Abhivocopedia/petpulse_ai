
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const HealthRecord = require('../models/HealthRecord');
const Pet = require('../models/Pet');

// Add health record
router.post('/', auth, async (req, res) => {
  try{
    const pet = await Pet.findById(req.body.pet);
    if(!pet) return res.status(404).json({ msg:'Pet not found' });
    if(pet.owner.toString() !== req.user.id) return res.status(401).json({ msg:'Not authorized' });
    const record = new HealthRecord(req.body);
    await record.save();
    res.json(record);
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

// Get records for pet
router.get('/pet/:petId', auth, async (req, res) => {
  try{
    const recs = await HealthRecord.find({ pet: req.params.petId });
    res.json(recs);
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

// Simple symptom-checker endpoint (AI-like simple rule-based)
router.post('/symptom-check', auth, async (req, res) => {
  try{
    const { symptoms } = req.body;
    let advice = 'Consult your vet for accurate diagnosis.';
    if(!symptoms || symptoms.length===0) return res.json({ advice, severity:'unknown' });
    const s = symptoms.join(' ').toLowerCase();
    if(s.includes('vomit') || s.includes('vomiting')) advice = 'Possible gastrointestinal issue. Keep hydrated and see vet.';
    else if(s.includes('letharg') || s.includes('weak')) advice = 'Low energy — monitor temperature and appetite; see vet if persists.';
    else if(s.includes('itch') || s.includes('scratch')) advice = 'Possible skin/allergy issue; check for fleas and skin lesions.';
    res.json({ advice, severity: 'low-medium' });
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

module.exports = router;
