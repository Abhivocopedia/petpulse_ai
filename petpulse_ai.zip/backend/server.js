
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/database');
const authRoutes = require('./routes/auth');
const petRoutes = require('./routes/pets');
const vaccinationRoutes = require('./routes/vaccinations');
const healthRoutes = require('./routes/health');

const app = express();
app.use(express.json());
app.use(cors({
  origin: process.env.FRONTEND_URL || '*'
}));

connectDB();

app.use('/api/auth', authRoutes);
app.use('/api/pets', petRoutes);
app.use('/api/vaccinations', vaccinationRoutes);
app.use('/api/health', healthRoutes);

app.get('/', (req, res) => res.send({status: 'PetPulse API running'}));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log('Server running on port', PORT));
