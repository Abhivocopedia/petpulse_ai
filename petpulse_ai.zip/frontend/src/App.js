
import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import { AuthProvider } from './context/AuthContext';
import './styles/App.css';

export default function App(){
  return (
    <AuthProvider>
      <BrowserRouter>
        <header className='app-header'>
          <h1>PetPulse AI</h1>
          <nav>
            <Link to='/'>Home</Link> | <Link to='/dashboard'>Dashboard</Link> | <Link to='/about'>About</Link>
          </nav>
        </header>
        <main className='app-main'>
          <Routes>
            <Route path='/' element={<Home/>} />
            <Route path='/about' element={<About/>} />
            <Route path='/contact' element={<Contact/>} />
            <Route path='/login' element={<Login/>} />
            <Route path='/register' element={<Register/>} />
            <Route path='/dashboard' element={<Dashboard/>} />
          </Routes>
        </main>
      </BrowserRouter>
    </AuthProvider>
  );
}
