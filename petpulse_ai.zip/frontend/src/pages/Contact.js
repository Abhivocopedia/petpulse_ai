
import React from 'react';
export default function Contact(){ return <div><h2>Contact</h2><p>support@petpulse.local</p></div>; }
