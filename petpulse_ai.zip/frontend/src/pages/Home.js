
import React from 'react';
export default function Home(){
  return (
    <div>
      <h2>PetPulse AI</h2>
      <p>The intelligent health OS for your pet — vaccines, records & vibes.</p>
    </div>
  );
}
