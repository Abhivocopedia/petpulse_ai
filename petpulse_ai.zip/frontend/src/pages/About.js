
import React from 'react';
export default function About(){
  return <div><h2>About</h2><p>PetPulse AI helps owners manage pet health.</p></div>;
}
