
import React, { useEffect, useState, useContext } from 'react';
import API from '../services/api';
import { AuthContext } from '../context/AuthContext';

export default function Dashboard(){
  const { user } = useContext(AuthContext);
  const [pets, setPets] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(()=>{
    async function load(){ 
      try{ const res = await API.get('/pets'); setPets(res.data); }
      catch(err){ console.error(err); }
      setLoading(false);
    }
    load();
  },[]);

  if(!user) return <p>Please login to view dashboard.</p>;
  return (
    <div>
      <h2>Welcome back, {user.name}</h2>
      {loading ? <p>Loading pets...</p> : (
        <div>
          {pets.length===0 ? <p>No pets yet. Add one!</p> : pets.map(p=> (
            <div key={p._id} className='pet-card'>
              <h4>{p.name} ({p.species})</h4>
              <p>Breed: {p.breed || '-'}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
