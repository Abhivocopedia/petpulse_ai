
import React, { useState, useContext } from 'react';
import API from '../services/api';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function Register(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const [error,setError]=useState('');
  const { login } = useContext(AuthContext);
  const nav = useNavigate();

  const handle = async e => {
    e.preventDefault();
    try{
      const res = await API.post('/auth/register',{ name, email, password });
      login(res.data.user, res.data.token);
      nav('/dashboard');
    }catch(err){
      setError(err.response?.data?.msg || 'Registration failed');
    }
  };

  return (
    <div className='card'>
      <h2>Register</h2>
      <form onSubmit={handle}>
        <input value={name} onChange={e=>setName(e.target.value)} placeholder='Name' required/>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder='Email' required/>
        <input value={password} onChange={e=>setPassword(e.target.value)} type='password' placeholder='Password' required/>
        <button>Register</button>
        {error && <p className='error'>{error}</p>}
      </form>
    </div>
  );
}
