
PetPulse AI - Deployment Guide (VULTR)
-------------------------------------
1. Upload project to your server (use scp or git).
2. Install Node.js (16+), npm, and MongoDB (or use managed MongoDB with connection string).
3. Backend:
   - cd backend
   - cp .env.example .env and fill values (MONGO_URI, JWT_SECRET, PORT)
   - npm install
   - npm run start (or use pm2 for production: pm2 start server.js --name petpulse-backend)
4. Frontend:
   - cd frontend
   - fill .env (REACT_APP_API_URL)
   - npm install
   - npm run build
   - Serve build with nginx by pointing root to frontend/build
5. Nginx reverse proxy config example below.

Notes:
- Replace 65.20.87.234 with your server IP or domain.
- Open required ports (80, 443). Use certbot to enable HTTPS.
